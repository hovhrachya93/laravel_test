<form action="<?php echo e(route('contact-form')); ?>" method="post">
<?php echo csrf_field(); ?>
<div class="form-group">
    <label for="name">name:</label>
    <input type="text" name="name" placeholder="enter name" id="name">
</div>

<div class="form-group">
    <label for="email">email:</label>
    <input type="text" name="email" placeholder="enter email" id="email">
</div>

<div class="form-group">
    <label for="subject">sms category</label>
    <input type="text" name="subject" placeholder="sms category" id="subject">
</div>

<div class="form-group">
    <label for="message">sms</label>
    <textarea name="message" class="form-control" id="message" placeholder="enter sms"></textarea>
</div>

<button type="submit" class="btn btn-success">send</button>
</form>
<?php /**PATH /Users/hovhrachya/Desktop/projects/php/laravel_project/resources/views/rename_employees.blade.php ENDPATH**/ ?>