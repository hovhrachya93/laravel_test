
<?php /**PATH /Users/hovhrachya/Desktop/projects/php/laravel_project/resources/views/auth/register.blade.php ENDPATH**/ ?>