<?php $__env->startSection('title-block'); ?>
    employees
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Employees table</h1>
    <table class="table">
        <thead class="thead-dark">
        <tr>
            <th scope="col">id</th>
            <th scope="col">First name</th>
            <th scope="col">last name</th>
            <th scope="col">Company</th>
            <th scope="col">Email</th>
            <th scope="col">Phone</th>
            <th scope="col">Rename</th>
            <th scope="col">Delete</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $employers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($employers->id); ?></th>
                <td> <?php echo e($employers->first_name); ?> </td>
                <td> <?php echo e($employers->last_name); ?> </td>
                <td>
                    <?php echo e($employers->company); ?>

                </td>
                <td> <?php echo e($employers->email); ?> </td>
                <td> <?php echo e($employers->phone); ?> </td>
                <!-- <td><a href="<?php echo e(url('/employee/'."{$employers->id}")); ?>" ><button class="btn btn-warning">rename</button></a></td> -->
                <td><a href="<?php echo e(url('employees/'.$employers->id.'/edit/')); ?>"<button class="btn btn-warning">rename</button></a></td>
                <form action="<?php echo e(route('employees.destroy', $employers->id)); ?>" method="DELETE">
                    <?php echo csrf_field(); ?>
                    <td><button type="submit" class="btn btn-danger">delete</button></td>
                </form>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <form action="<?php echo e(route('employee-form')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <tr >
                <th scope="row"><p>add fields</p></th>
                <td>First Name: <input type="text"  name="first_name"></td>
                <td>Last Name: <input type="text" name="last_name"></td>
                <td>Company: <select name="company" id="">
                        <option value="">Choose Company</option>
                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value=<?php echo e($company->name); ?>><?php echo e($company->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select></td>
                <td>Email: <input type="text" name="email"></td>
                <td>Phone: <input type="text" name="phone"></td>
                <td><button type="submit" class="btn btn-primary">send fields</button></td>
            </tr>
        </form>
        </tbody>
    </table>

    <ul class="pagination">
        <?php echo e($employers->links()); ?>

    </ul>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?><li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </ul>
        </div>
    <?php endif; ?>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.mainapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/hovhrachya/Desktop/projects/php/laravel_project/resources/views/employees/index.blade.php ENDPATH**/ ?>