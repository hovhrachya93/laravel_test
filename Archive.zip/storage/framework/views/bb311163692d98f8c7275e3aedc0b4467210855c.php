<?php $__env->startSection('title-block'); ?>
    companies
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Companies table</h1>

    <table class="table">
        <thead class="thead-dark">
        <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Email</th>
            <th scope="col">Logo</th>
            <th scope="col">Website</th>
            <th scope="col">Rename</th>
            <th scope="col">Delete</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($company->id); ?></th>
                <td> <?php echo e($company->name); ?> </td>
                <td> <?php echo e($company->email); ?> </td>
                <td> <img src="<?php echo e(asset('storage/'.$company->logo)); ?>"  height="42" width="42"> </td>
                <td> <?php echo e($company->website); ?> </td>
                <td><a href="<?php echo e(url('/company/'."{$company->id}")); ?>" ><button class="btn btn-warning">rename</button></a></td>
                <form action="<?php echo e(url('/company/'."{$company->id}".'/delete')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <td><button type="submit" class="btn btn-danger">delete</button></td>
                </form>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <form action="<?php echo e(route('company-form')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
        <tr>
            <th scope="row"><p>add fields</p></th>
            <td>Name: <input type="text" name="name"></td>
            <td>Email: <input type="text" name="email"></td>
            <td>Logo: <input type="file" name="logo"></td>
            <td>Website: <input type="text" name="website"></td>
            <td><button class="btn btn-primary">send fields</button></td>
        </tr>
        </form>
        </tbody>
    </table>
    <ul class="pagination">
        <?php echo e($companies->links()); ?>

    </ul>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?><li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </ul>
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/hovhrachya/Desktop/projects/php/laravel_project/resources/views/companies.blade.php ENDPATH**/ ?>