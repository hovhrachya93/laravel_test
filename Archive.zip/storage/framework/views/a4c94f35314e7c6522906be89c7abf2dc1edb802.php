<?php $__env->startSection('title-block'); ?>
    rename company
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Company table with <span style="color: darkred"> <?php echo e($company->id); ?> </span> id</h1>
    <form action="<?php echo e(route('company-update', $company->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field("PUT"); ?>
        <table class="table">
            <thead class="thead-dark">
            <tr>
                <th scope="col">Name</th>
                <th scope="col">Email</th>
                <th scope="col">Logo</th>
                <th scope="col">Website</th>
                <th scope="col">Rename</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td><input type="text" placeholder="<?php echo e($company->name); ?>" name="name" value="<?php echo e($company->name); ?>"></td>
                <td><input type="text" placeholder="<?php echo e($company->email); ?>" name="email" value="<?php echo e($company->email); ?>"></td>
                <td><input type="file"  name="logo" ></td>
                <td><input type="text" placeholder="<?php echo e($company->website); ?>" name="website" value="<?php echo e($company->website); ?>"></td>
                <td><button class="btn btn-warning">save</button></td>
            </tr>
            </tbody>
        </table>
    </form>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?><li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </ul>
        </div>
    <?php endif; ?>


<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.mainapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/hovhrachya/Desktop/projects/php/laravel_project/resources/views/renameCompany.blade.php ENDPATH**/ ?>