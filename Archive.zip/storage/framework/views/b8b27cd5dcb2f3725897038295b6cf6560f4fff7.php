<div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom shadow-sm">
    <h5 class="my-0 mr-md-auto font-weight-normal">Cretix test</h5>
    <nav class="my-2 my-md-0 mr-md-3">
        <a class="p-2 text-dark" href="<?php echo e(url('/home')); ?>">Main</a>
        <a class="p-2 text-dark" href="<?php echo e(url('/companies')); ?>">Companies</a>
        <a class="p-2 text-dark" href="<?php echo e(route('employees')); ?>">Employees</a>
    </nav>
    <a class="btn btn-outline-primary" href="<?php echo e(url('/logout')); ?>">Log out</a>
</div>

<?php /**PATH /Users/hovhrachya/Desktop/projects/php/laravel_project/resources/views/inc/header.blade.php ENDPATH**/ ?>