<?php $__env->startSection('title-block'); ?>
    rename employee
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Employee table with <span style="color: darkred"> <?php echo e($employee->id); ?> </span> id</h1>
    <form action="<?php echo e(route('employee-update', $employee->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <table class="table">
            <thead class="thead-dark">
            <tr>
                <th scope="col">First name</th>
                <th scope="col">last name</th>
                <th scope="col">Company</th>
                <th scope="col">Email</th>
                <th scope="col">Phone</th>
                <th scope="col">Rename</th>
            </tr>
            </thead>
            <tbody>
                <tr>
                    <td><input type="text" placeholder="<?php echo e($employee->first_name); ?>" name="first_name" value="<?php echo e($employee->first_name); ?>"></td>
                    <td><input type="text" placeholder="<?php echo e($employee->last_name); ?>" name="last_name" value="<?php echo e($employee->last_name); ?>"></td>
                    <td><input type="text" placeholder="<?php echo e($employee->company); ?>" name="company" value="<?php echo e($employee->company); ?>"></td>
                    <td><input type="text" placeholder="<?php echo e($employee->email); ?>" name="email" value="<?php echo e($employee->email); ?>"></td>
                    <td><input type="text" placeholder="<?php echo e($employee->phone); ?>" name="phone"  value="<?php echo e($employee->phone); ?> "></td>
                    <td><button class="btn btn-warning">save</button></td>
                </tr>
            </tbody>
        </table>
    </form>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?><li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </ul>
        </div>
    <?php endif; ?>


<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.mainapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/hovhrachya/Desktop/projects/php/laravel_project/resources/views/renameEmployee.blade.php ENDPATH**/ ?>